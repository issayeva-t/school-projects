package encryption;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JEditorPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import javax.swing.JTabbedPane;
import javax.swing.JComboBox;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollBar;

public class Encryptioncide {

	private JFrame frame;
	private JTextField txtLogin;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Encryptioncide window = new Encryptioncide();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public Encryptioncide() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		CardLayout myLayout=new CardLayout();
		frame.getContentPane().setLayout(myLayout); 
		
		
		JPanel LoginPage = new JPanel();
		frame.getContentPane().add(LoginPage, "LoginPage");
		LoginPage.setLayout(null);
		
		txtLogin = new JTextField();
		txtLogin.setFont(new Font("Arial", Font.PLAIN, 14));
		txtLogin.setBounds(68, 70, 283, 23);
		LoginPage.add(txtLogin);
		txtLogin.setColumns(10);
					
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
		passwordField.setToolTipText("");
		passwordField.setBounds(68, 144, 283, 20);
		LoginPage.add(passwordField);
		
		JButton btnNewButton = new JButton("enter");
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton.setBounds(169, 212, 89, 23);
		LoginPage.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			String login = txtLogin.getText(); 
			char[] Pass=passwordField.getPassword();
			String password=new String(Pass);
			if ((login.equals("Rustam"))&&(password.equals("Qqwerty1!"))) {
				myLayout.show(frame.getContentPane(), "Encode");
			}
			else {
				JOptionPane.showMessageDialog(null, "please check login or password");
			}
			}
		});
		
		JLabel lblNewLabel = new JLabel("login");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel.setBounds(68, 46, 61, 23);
		LoginPage.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("password");
		lblPassword.setFont(new Font("Arial", Font.PLAIN, 14));
		lblPassword.setBounds(68, 121, 71, 23);
		LoginPage.add(lblPassword);
		LoginPage.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{lblNewLabel, txtLogin, lblPassword, passwordField, btnNewButton}));
		
		/*
		 ENCODING PAGE!!!!!!!!
		 */
		
		JPanel EncodePage = new JPanel();
		frame.getContentPane().add(EncodePage, "Encode");
		EncodePage.setLayout(null);
		
		JPanel menu1 = new JPanel();
		menu1.setLayout(null);
		menu1.setBackground(Color.LIGHT_GRAY);
		menu1.setBounds(0, 422, 434, 40);
		EncodePage.add(menu1);
		
		JButton btnE1 = new JButton("Encode");
		btnE1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				myLayout.show(frame.getContentPane(), "encode");
			}
		});
		btnE1.setForeground(Color.BLACK);
		btnE1.setFont(new Font("Arial", Font.PLAIN, 25));
		btnE1.setBackground(new Color(250, 250, 210));
		btnE1.setBounds(0, 0, 145, 40);
		menu1.add(btnE1);
		
		
		
		JButton btnD1 = new JButton("Decode");
		btnD1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				myLayout.show(frame.getContentPane(), "decode");
			}
		});
		btnD1.setForeground(Color.BLACK);
		btnD1.setFont(new Font("Arial", Font.PLAIN, 25));
		btnD1.setBackground(new Color(250, 250, 210));
		btnD1.setBounds(145, 0, 145, 40);
		menu1.add(btnD1);
		
		
		JButton btnS1 = new JButton("Settings");
		btnS1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				myLayout.show(frame.getContentPane(), "settings");
			}
		});
		btnS1.setForeground(Color.BLACK);
		btnS1.setFont(new Font("Arial", Font.PLAIN, 25));
		btnS1.setBackground(new Color(250, 250, 210));
		btnS1.setBounds(290, 0, 145, 40);
		menu1.add(btnS1);
		
		JLabel lblEncode = new JLabel("encode");
		lblEncode.setFont(new Font("Tahoma", Font.PLAIN, 66));
		lblEncode.setBounds(96, 0, 230, 64);
		EncodePage.add(lblEncode);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Arial", Font.PLAIN, 25));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Caesar", "Atbash", "Vegener"}));
		comboBox.setBounds(21, 75, 145, 35);
		EncodePage.add(comboBox);
		
		/*
		  DECODING PAGE!!!!!!!!
		 */
		
		JPanel DecodePage = new JPanel();
		frame.getContentPane().add(DecodePage, "decode");
		DecodePage.setLayout(null);
		
		JPanel menu2 = new JPanel();
		menu2.setBounds(0, 422, 434, 40);
		DecodePage.add(menu2);
		menu2.setBackground(Color.LIGHT_GRAY);
		menu2.setLayout(null);
		
		JButton btnE2 = new JButton("Encode");
		btnE2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				myLayout.show(frame.getContentPane(), "encode");
			}
		});
		btnE2.setForeground(Color.BLACK);
		btnE2.setFont(new Font("Arial", Font.PLAIN, 25));
		btnE2.setBackground(new Color(250, 250, 210));
		btnE2.setBounds(0, 0, 145, 40);
		menu2.add(btnE2);
		
		JButton btnD2 = new JButton("Decode");
		btnD2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				myLayout.show(frame.getContentPane(), "decode");
			}
		});
		btnD2.setForeground(Color.BLACK);
		btnD2.setFont(new Font("Arial", Font.PLAIN, 25));
		btnD2.setBackground(new Color(250, 250, 210));
		btnD2.setBounds(145, 0, 145, 40);
		menu2.add(btnD2);
		
		JButton btnS2 = new JButton("Settings");
		btnS2.setBounds(290, 0, 145, 40);
		menu2.add(btnS2);
		btnS2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				myLayout.show(frame.getContentPane(), "settings");
			}
		});
		btnS2.setForeground(Color.BLACK);
		btnS2.setFont(new Font("Arial", Font.PLAIN, 25));
		btnS2.setBackground(new Color(250, 250, 210));
		
		JLabel lblDecode = new JLabel("decode");
		lblDecode.setFont(new Font("Tahoma", Font.PLAIN, 56));
		lblDecode.setBounds(96, 58, 205, 93);
		DecodePage.add(lblDecode);

		/*
		  Settings PAGE!!!!!!!!
		 */
		
		JPanel SettingsPage = new JPanel();
		frame.getContentPane().add(SettingsPage, "settings");
		SettingsPage.setLayout(null);
		
		JPanel menu3 = new JPanel();
		menu3.setLayout(null);
		menu3.setBackground(Color.LIGHT_GRAY);
		menu3.setBounds(0, 422, 434, 40);
		SettingsPage.add(menu3);
		
		JButton btnE3 = new JButton("Encode");
		btnE3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				myLayout.show(frame.getContentPane(), "encode");
			}
		});
		btnE3.setForeground(Color.BLACK);
		btnE3.setFont(new Font("Arial", Font.PLAIN, 25));
		btnE3.setBackground(new Color(250, 250, 210));
		btnE3.setBounds(0, 0, 145, 40);
		menu3.add(btnE3);
		
		JButton btnD3 = new JButton("Decode");
		btnD3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				myLayout.show(frame.getContentPane(), "decode");
			}
		});
		btnD3.setForeground(Color.BLACK);
		btnD3.setFont(new Font("Arial", Font.PLAIN, 25));
		btnD3.setBackground(new Color(250, 250, 210));
		btnD3.setBounds(145, 0, 145, 40);
		menu3.add(btnD3);
		
		JButton btnS3 = new JButton("Settings");
		btnS3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				myLayout.show(frame.getContentPane(), "settings");
			}
		});
		btnS3.setForeground(Color.BLACK);
		btnS3.setFont(new Font("Arial", Font.PLAIN, 25));
		btnS3.setBackground(new Color(250, 250, 210));
		btnS3.setBounds(290, 0, 145, 40);
		menu3.add(btnS3);
		
		JLabel lblSettings = new JLabel("settings");
		lblSettings.setFont(new Font("Tahoma", Font.PLAIN, 58));
		lblSettings.setBounds(115, 63, 258, 140);
		SettingsPage.add(lblSettings);
	}
}
;
	
