import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import javax.swing.ImageIcon;
import javax.swing.JProgressBar;

public class PhychologicalTest {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PhychologicalTest window = new PhychologicalTest();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PhychologicalTest() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		CardLayout myLayout=new CardLayout();
		frame.getContentPane().setLayout(myLayout);
		
		JPanel start_page = new JPanel();
		frame.getContentPane().add(start_page, "start_page");
		start_page.setLayout(null);
		
		JLabel lblPersonalTest = new JLabel("Personal Test");
		lblPersonalTest.setFont(new Font("Old English Text MT", Font.PLAIN, 60));
		lblPersonalTest.setBounds(50, 0, 370, 70);
		start_page.add(lblPersonalTest);
		
		JButton button = new JButton("\u041D\u0430\u0447\u0430\u0442\u044C \u0442\u0435\u0441\u0442");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				myLayout.show(frame.getContentPane(),"que1");
				}
		});
		button.setBounds(150, 420, 160, 25);
		start_page.add(button);
		button.setFont(new Font("Cambria", Font.PLAIN, 14));
		
		JTextArea textArea = new JTextArea();
		textArea.setBackground(UIManager.getColor("Button.background"));
		textArea.setFont(new Font("Cambria", Font.PLAIN, 13));
		textArea.setText("\u0421\u043F\u0430\u0441\u0438\u0442\u0435\u043B\u044C, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u0432\u043C\u0435\u0448\u0438\u0432\u0430\u0435\u0442\u0441\u044F, \u043A\u0430\u043A \u043A\u0430\u0436\u0435\u0442\u0441\u044F, \u0438\u0437 \u0436\u0435\u043B\u0430\u043D\u0438\u044F \u043F\u043E\u043C\u043E\u0447\u044C \r\n\u0441\u0438\u0442\u0443\u0430\u0446\u0438\u0438 \u0438\u043B\u0438 \u0441\u043B\u0430\u0431\u043E\u043C\u0443. \n\u041A\u0440\u043E\u043C\u0435 \u0432\u044B\u0448\u0435\u043F\u0435\u0440\u0435\u0447\u0438\u0441\u043B\u0435\u043D\u043D\u044B\u0445 \u0440\u043E\u043B\u0435\u0439, \u0435\u0441\u0442\u044C \u0442\u0430\u043A\u0436\u0435 \r\n\u0440\u043E\u043B\u044C \u041D\u0430\u0431\u043B\u044E\u0434\u0430\u0442\u0435\u043B\u044F- \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430 \u043D\u0435 \u0432\u043E\u0432\u043B\u0435\u043A\u0430\u044E\u0449\u0435\u0433\u043E\u0441\u044F \u0432 \u0442\u0440\u0435\u0443\u0433\u043E\u043B\u044C\u043D\u0438\u043A. \r\n\u0425\u043E\u0442\u0438\u0442\u0435 \u0443\u0437\u043D\u0430\u0442\u044C \u043A\u0435\u043C \u044F\u0432\u043B\u044F\u0435\u0442\u0435\u0441\u044C \u0432\u044B?");
		textArea.setBounds(20, 320, 408, 84);
		start_page.add(textArea);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(""));
		lblNewLabel.setBounds(20, 69, 248,248);
		start_page.add(lblNewLabel);
		
		JTextArea textArea_2 = new JTextArea();
		textArea_2.setBackground(UIManager.getColor("Button.background"));
		textArea_2.setFont(new Font("Cambria", Font.PLAIN, 13));
		textArea_2.setText("\u0422\u0440\u0435\u0443\u0433\u043E\u043B\u044C\u043D\u0438\u043A \u041A\u0430\u0440\u043F\u043C\u0430\u043D\u0430\u2014 \r\n\u044D\u0442\u043E \u043F\u0441\u0438\u0445\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0438 \r\n\u0441\u043E\u0446\u0438\u0430\u043B\u044C\u043D\u0430\u044F \u043C\u043E\u0434\u0435\u043B\u044C \r\n\u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043C\u0435\u0436\u0434\u0443 \u043B\u044E\u0434\u044C\u043C\u0438. \r\n\u041C\u043E\u0434\u0435\u043B\u044C \u043E\u043F\u0438\u0441\u044B\u0432\u0430\u0435\u0442 \u0442\u0440\u0438 \r\n\u043F\u0440\u0438\u0432\u044B\u0447\u043D\u044B\u0435 \u043F\u0441\u0438\u0445\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \r\n\u0440\u043E\u043B\u0438 (\u0438\u043B\u0438 \u0440\u043E\u043B\u0435\u0432\u044B\u0435 \u0438\u0433\u0440\u044B), \r\n\u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u043B\u044E\u0434\u0438 \u0447\u0430\u0441\u0442\u043E \u0437\u0430\u043D\u0438\u043C\u0430\u044E\u0442 \r\n\u0432 \u0441\u0438\u0442\u0443\u0430\u0446\u0438\u044F\u0445: \r\n\u041F\u0435\u0440\u0441\u043E\u043D\u0430\u0436, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u0438\u0433\u0440\u0430\u0435\u0442 \u0440\u043E\u043B\u044C \r\n\u0436\u0435\u0440\u0442\u0432\u044B. \u041F\u0435\u0440\u0441\u043E\u043D\u0430\u0436, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \r\n\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u0434\u0430\u0432\u043B\u0435\u043D\u0438\u0435, \u043F\u0440\u0438\u043D\u0443\u0436\u0434\u0430\u0435\u0442 \r\n\u0438\u043B\u0438 \u043F\u0440\u0435\u0441\u043B\u0435\u0434\u0443\u0435\u0442 \u0436\u0435\u0440\u0442\u0432\u0443 \u2014 \r\n\u043F\u0440\u0435\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C. ");
		textArea_2.setBounds(268, 81, 206, 233);
		start_page.add(textArea_2);
		
		JPanel que1 = new JPanel();
		frame.getContentPane().add(que1, "que1");
		que1.setLayout(null);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setBackground(UIManager.getColor("Button.background"));
		textArea_1.setFont(new Font("Cambria", Font.PLAIN, 18));
		textArea_1.setText("\u0412\u043E\u043F\u0440\u043E\u0441 1:  \u0423 \u0432\u0430\u0441 \u043D\u0430 \u0440\u0430\u0431\u043E\u0442\u0435/ \u0432 \u0448\u043A\u043E\u043B\u0435  \r\n\u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u0438\u043B\u0438 \u043E\u0431\u044A\u0435\u043C\u043D\u0443\u044E \u0440\u0430\u0431\u043E\u0442\u0443 \u043D\u0430 \r\n\u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0447\u0435\u043B\u043E\u0432\u0435\u043A. \u0412\u0430\u0448\u0430 \u0440\u043E\u043B\u044C \r\n\u0432 \u043A\u043E\u043C\u0430\u043D\u0434\u0435: \r\n");
		textArea_1.setBounds(69, 50, 350, 90);
		que1.add(textArea_1);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("\u042F \u043D\u0435 \u0432\u043D\u043E\u0448\u0443 \u0432\u043A\u043B\u0430\u0434 \u0432 \u043A\u043E\u043C\u0430\u043D\u0434\u043D\u043E\u0439 \u0440\u0430\u0431\u043E\u0442\u0435, \r\n\u043F\u0435\u0440\u0435\u043A\u043B\u0430\u0434\u044B\u0432\u0430\u044F \u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0441\u0442\u044C \u043D\u0430 \u0442\u0435\u0445, \r\n\u043A\u0442\u043E \u0431\u043E\u043B\u0435\u0435 \u0442\u0440\u0443\u0434\u043E\u0441\u043F\u043E\u0441\u043E\u0431\u043D\u044B\u0439.");
		rdbtnNewRadioButton.setFont(new Font("Cambria", Font.PLAIN, 14));
		rdbtnNewRadioButton.setBounds(70, 180, 334, 65);
		que1.add(rdbtnNewRadioButton);
		
		
		JPanel que2 = new JPanel();
		frame.getContentPane().add(que2, "que2");
		
		JPanel que3 = new JPanel();
		frame.getContentPane().add(que3, "que3");
		
		JPanel que4 = new JPanel();
		frame.getContentPane().add(que4, "que4");
		que4.setLayout(null);
		
		JPanel que5 = new JPanel();
		frame.getContentPane().add(que5, "que5");
		que5.setLayout(null);
		
		JPanel que6 = new JPanel();
		frame.getContentPane().add(que6, "que6");
		que6.setLayout(null);
		
		JPanel que7 = new JPanel();
		frame.getContentPane().add(que7, "que7");
		que7.setLayout(null);
		
		JPanel que8 = new JPanel();
		frame.getContentPane().add(que8, "que8");
		que8.setLayout(null);
		
		JPanel que9 = new JPanel();
		frame.getContentPane().add(que9, "que9");
		que9.setLayout(null);
		
		JPanel que10 = new JPanel();
		frame.getContentPane().add(que10, "que10");
		que10.setLayout(null);
		
		JPanel resultA = new JPanel();
		frame.getContentPane().add(resultA, "resultA");
		
		JPanel resultB = new JPanel();
		frame.getContentPane().add(resultB, "resultB");
		
		JPanel resultC = new JPanel();
		frame.getContentPane().add(resultC, "resultC");
		
		JPanel resultD = new JPanel();
		frame.getContentPane().add(resultD, "resultD");
	}
}
